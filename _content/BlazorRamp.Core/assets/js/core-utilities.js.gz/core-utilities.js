const getScreenInnerWidth = () => window.innerWidth;
export { getScreenInnerWidth };
//# sourceMappingURL=core-utilities.js.map