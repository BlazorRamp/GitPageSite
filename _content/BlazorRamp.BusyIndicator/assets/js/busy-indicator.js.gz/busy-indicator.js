const _tabFocusElements = 'a[href], area[href], input:not([disabled]):not([type="hidden"]),select:not([disabled]), textarea:not([disabled]),button:not([disabled]),iframe, object,embed, [contenteditable],[tabindex]:not([tabindex="-1"]),audio[controls],video[controls],summay';
const ANNOUNCEMENT_COMPONENTS_ID = "blazor-ramp-announcement-history-components";
const BS_COMPONENT_NAME = "Busy Indicator";
const AH_COMPONENT_NAME = "Announcement History";
const INERT_ATTRIBUTE = "inert";
const BR_INERT_ATTRIBUTE = "data-br-inert";
const BUSY_INDICATOR_TIMEOUT = 30000;
const _indicatorMap = new WeakMap();
const _ahCompsElement = document.getElementById(ANNOUNCEMENT_COMPONENTS_ID);
const _ahCompsOriginalParent = _ahCompsElement?.parentElement ?? null;
/*
    * To simplify things I moved the live regions into the announcment history container so everything in this container does not
    * get the inert attribute added. I also chack and move everything to the body element.
*/
const getSetInertElements = (busyElement, activatingElement, inertElements = []) => {
    if (!busyElement || !busyElement.parentElement)
        return inertElements;
    Array.from(busyElement.parentElement.children).forEach(child => {
        if (child !== busyElement && child instanceof HTMLElement)
            inertElements = recurseTree(child, busyElement.id, activatingElement, inertElements);
    });
    return inertElements;
};
const recurseTree = (element, busyElementId, activatingElement, inertElements = []) => {
    const tagName = element.tagName.toLowerCase();
    const shouldSkip = element.hasAttribute(INERT_ATTRIBUTE) || element.getAttribute("aria-live") !== null ||
        element.getAttribute("data-br-component") === BS_COMPONENT_NAME || element.id === ANNOUNCEMENT_COMPONENTS_ID ||
        element.getAttribute("data-br-component") === AH_COMPONENT_NAME || element.getAttribute("role") === "alert" ||
        tagName === "script";
    if (shouldSkip)
        return inertElements;
    if (activatingElement && element.contains(activatingElement)) {
        Array.from(element.children).forEach(child => {
            if (child instanceof HTMLElement && child !== activatingElement)
                inertElements = recurseTree(child, busyElementId, activatingElement, inertElements);
        });
        return inertElements;
    }
    element.setAttribute(INERT_ATTRIBUTE, "true");
    element.setAttribute(BR_INERT_ATTRIBUTE, busyElementId);
    inertElements.push(element);
    return inertElements;
};
const checkIsInsideDialog = (busyElement) => {
    if (!busyElement)
        return [null, false];
    const dialogTagName = "dialog";
    let parentElement = busyElement.parentElement;
    while (parentElement) {
        if (parentElement.tagName.toLowerCase() === dialogTagName) {
            return [parentElement, true];
        }
        parentElement = parentElement.parentElement;
    }
    return [null, false];
};
const getParentElement = (busyElement, overlay) => {
    const [dialogElement, inDialog] = checkIsInsideDialog(busyElement);
    if (overlay.toLowerCase() === "container")
        return [busyElement.parentElement, inDialog];
    if (dialogElement)
        return [dialogElement, inDialog];
    return [document.body, false];
};
const checkRemoveInertById = (elementId) => {
    document.querySelectorAll(`[data-br-inert="${elementId}"]`).forEach(el => {
        el.removeAttribute(INERT_ATTRIBUTE);
        el.removeAttribute(BR_INERT_ATTRIBUTE);
    });
};
const startBusyIndicator = (busyElement, displayModifier, timeout = BUSY_INDICATOR_TIMEOUT, overlay = "container") => {
    if (!busyElement || !busyElement.parentElement)
        return;
    let [targetParent, inDialog] = getParentElement(busyElement, overlay);
    targetParent = targetParent ?? busyElement.parentElement; //should be no nulls here but keep typscript happy
    checkRemoveInertById(busyElement.id); //safety net incase same indicator gets started stopped out of sequence.
    let indicatorData = _indicatorMap.get(busyElement);
    if (!indicatorData) {
        indicatorData = { element: busyElement, originalParent: busyElement.parentElement, displayModifier: displayModifier, inModalDialog: inDialog };
        _indicatorMap.set(busyElement, indicatorData);
    }
    const { element, displayModifier: modifier } = indicatorData;
    if (!element.classList.contains(modifier))
        element.classList.add(modifier);
    if (element.parentElement !== targetParent)
        targetParent.appendChild(element);
    indicatorData.activatingElement = document?.activeElement;
    indicatorData.inertElements = getSetInertElements(element, indicatorData.activatingElement);
    if (indicatorData.timerId)
        clearTimeout(indicatorData.timerId);
    const timerId = setTimeout(() => {
        stopBusyIndicator(element);
    }, timeout);
    indicatorData.timerId = timerId;
};
const stopBusyIndicator = (busyElement) => {
    const indicatorData = _indicatorMap.get(busyElement);
    if (!indicatorData)
        return;
    const { element, originalParent, timerId, displayModifier, inertElements, inModalDialog, activatingElement } = indicatorData;
    if (timerId) {
        clearTimeout(timerId);
        indicatorData.timerId = undefined;
    }
    //inertElements?.forEach(inertElement => inertElement.removeAttribute(INERT_ATTRIBUTE));
    checkRemoveInertById(busyElement.id); //nano seconds slower but safer
    indicatorData.inertElements = undefined;
    if (element.parentElement !== originalParent) {
        originalParent.appendChild(element);
    }
    if (activatingElement && activatingElement.isConnected && !activatingElement.hasAttribute('disabled') && activatingElement.getAttribute('aria-disabled') !== 'true') {
        const currentActiveElement = document.activeElement;
        if (currentActiveElement === activatingElement || currentActiveElement == document.body
            || currentActiveElement === busyElement)
            activatingElement.focus();
    }
    element.classList.remove(displayModifier);
    _indicatorMap.delete(busyElement);
};
export { startBusyIndicator, stopBusyIndicator };
//# sourceMappingURL=busy-indicator.js.map